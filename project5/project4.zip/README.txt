Cole Smith

I worked on this project alone.

I had trouble with getting the previous questions to be stored properly. I was experiencing a weird problem where my questions had a 'register' escape character that basically moves the cursor to the beginning of the line, which i fixed by using a substring to remove it. I also had trouble with expanding the tree and getting the user input to be put into the tree correctly.

I really liked how almost all of the project was up to us to create without just following an exact outline of what algorithm to use and how to use it. It made it more challenging but also more satisfying to complete.

I worked on this project for 4 days all in, but most of the work was grinded out in one long sitting, with the rest of it being bux fixing and refinement.

I didn't really add any fun features. The only thing I added that wasn't really needed for the project was a print function that prints mroe than just the file as is; it formats it to where each layer can be visualized a little bit easier. 
