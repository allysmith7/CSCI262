Cole Smith

I worked on this project alone.

I implemented the clock_time class with individual variables for seconds, minutes, and hours, as I felt it was easier for
me to conceptualize the class this way. If this is a problem, I have no problem redoing it.