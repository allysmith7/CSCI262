1. Name & Help

    My name is Cole Smith, I worked on this project alone. I used the following websites as resources.
    - http://www.cplusplus.com/reference/stdexcept/out_of_range/
    - https://www.geeksforgeeks.org/how-to-convert-a-single-character-to-string-in-cpp/
    - https://www.geeksforgeeks.org/stack-in-cpp-stl/

2. Problems

    I had a challenge where I was getting a segmentation fault when trying to check each point to see if it was in the
    bounds of the maze because I was using a try-catch. I changed this to two if statements which worked better.

    I also had a problem where my program would require me to hit enter multiple times at the end of the program, but it
    was actually just checking the final point a final time and popping it off the stack/queue before saying it was done.

3. Like/Dislike

    I liked that the majority of the grunt work was written out and that we didn't have to spend our time typing out the
    print statements; we just needed to work on writing the algorithm for the solving and that stuff.

4. Time Spent

    I spent maybe 4 hours working on this project all in. 2 hours doing the initial work of writing the algorithm, 1 hour
    fixing bugs and 1 hour testing/cleaning up the code.